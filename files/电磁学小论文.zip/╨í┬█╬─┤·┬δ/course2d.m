clc,clear,close;
x=[];y=[];z=[]; 
dT=5*10^-2;
X=10;Y=0;Z=0;Vx=0;Vy=10;
mu=5.9*9.2732*10^-24;
k=5*10^-3;
m=9.296*10^-26;
i=0;
a=k*mu/m;
plot(X,Y,'o','Color','blue')
  
   hold on;
for t=0:dT:30
    i=i+1;
    x(i)=X;y(i)=Y;z(i)=Z;
    Ax=-2*a*(sqrt(x(i)^2+y(i)^2)-10)*x(i)/sqrt(x(i)^2+y(i)^2);
    Ay=-2*a*(sqrt(x(i)^2+y(i)^2)-10)*y(i)/sqrt(x(i)^2+y(i)^2);
    deltaX=Vx*dT+0.5*Ax*dT*dT;
    deltaY=Vy*dT+0.5*Ay*dT*dT;
    X1=X+deltaX;
    Y1=Y+deltaY;
    Z1=(sqrt(x(i)^2+y(i)^2)-10)^2;
    V1=Ax*dT+Vx;
    V2=Ay*dT+Vy;
   
    plot(X1,Y1,'.','Color','red','Linewidth',0.25);
    grid on;
    grid minor;

   axis ([-20 20 -20 20]);
    hold on;
    pause(0.00001)

    X=X1;Y=Y1;Z=Z1;Vx=V1;Vy=V2;
end 
plot(X,Y,'o','Color','green')