[X,Y] = meshgrid(-10:0.1:10); 
R = sqrt(X.^2 + Y.^2) + eps;
Z = R;
surf(X,Y,Z,'FaceAlpha',0.2,'EdgeColor','none')
hold on;
for i=1:1:6741
    plot3([x(i),x(i+1)],[y(i),y(i+1)],[z(i),z(i+1)],'Color','red','Linewidth',0.5);
    if i==1 
        grid on;
        grid minor;
    end
    hold on;
    axis equal;
end 
hold off
