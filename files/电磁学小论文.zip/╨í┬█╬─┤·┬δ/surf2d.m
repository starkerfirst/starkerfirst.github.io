clc,clear,close;
x=[];y=[];z=[]; 
dT=10^-3;
X=6;Y=0;Z=6;Vx=0;Vy=2;
mu=5.9*9.2732*10^-24;
k=10^-1;
m=9.296*10^-26;
i=0;
a=k*mu/m;
plot(X,Y,'o','Color','blue')
 
   hold on;
for t=0:dT:10
    i=i+1;
    x(i)=X;y(i)=Y;z(i)=Z;
    Ax=-a*x(i)/sqrt(x(i)^2+y(i)^2);
    Ay=-a*y(i)/sqrt(x(i)^2+y(i)^2);
    deltaX=Vx*dT+0.5*Ax*dT*dT;
    deltaY=Vy*dT+0.5*Ay*dT*dT;
    X1=X+deltaX;
    Y1=Y+deltaY;
    Z1=sqrt(X1^2+Y1^2);
    V1=Ax*dT+Vx;
    V2=Ay*dT+Vy;
   
    plot(X1,Y1,'.','Color','red','Linewidth',0.25);
  axis ([-10 10 -10 10]);
    grid on;
    grid minor
    hold on;
    

    X=X1;Y=Y1;Z=Z1;Vx=V1;Vy=V2;
end 
plot(X,Y,'o','Color','green')