clc,clear,close;
x=[];y=[];z=[]; 
dT=10000000000000000000;
d=10^1;
X=2*d;Y=0;Vx=0;Vy=0.01;
mu=5.9*9.2732*10^-24;
k=1.2566*10^4;
m=9.296*10^-26;
i=0;

a=3*k*mu/(2*pi*m);

for t=0:dT:1000000000000000000000000000000000000
    i=i+1;
    x(i)=X;y(i)=Y;
    Ax=-a*(sqrt(x(i)^2+y(i)^2)-2*d)*(sqrt(x(i)^2+y(i)^2)+2*d)*x(i)/(d^2+x(i)^2+y(i)^2)^(7/2);
    Ay=-a*(sqrt(x(i)^2+y(i)^2)-2*d)*(sqrt(x(i)^2+y(i)^2)+2*d)*y(i)/(d^2+x(i)^2+y(i)^2)^(7/2);
    deltaX=Vx*dT+0.5*Ax*dT*dT;
    deltaY=Vy*dT+0.5*Ay*dT*dT;
    X1=X+deltaX;
    Y1=Y+deltaY;
    V1=Ax*dT+Vx;
    V2=Ay*dT+Vy;
    plot(t,sqrt(x(i)^2+y(i)^2),'.','Color','red','Linewidth',0.25);
    grid on;
    grid minor;
    hold on;
    pause(0.000001)
    X=X1;Y=Y1;Vx=V1;Vy=V2;
end 




